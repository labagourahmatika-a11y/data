# Data Operasional Catering

Paket ini mengubah isi `data.xlsx` menjadi format yang lebih mudah dibagikan dan dibaca.

## Isi folder
- `index.html`: halaman web sederhana untuk menampilkan tabel.
- `data.json`: seluruh data dalam satu file JSON.
- `aktivitas.csv`: estimasi durasi dan jumlah pekerja.
- `jam_orang.csv`: perhitungan jam-orang (jumlah pekerja × durasi).
- `pembagian_karyawan.csv`: pembagian aktivitas karyawan A–I.
- `pesanan_31_oktober_2026.csv`: data menu/pesanan dari file sumber.

## Agar dapat diakses siapa pun melalui internet (gratis)
1. Buat akun atau masuk ke https://github.com
2. Buat repository baru, misalnya `data-operasional-catering`.
3. Atur repository menjadi **Public**.
4. Unggah semua file dari folder ini (bukan hanya file ZIP).
5. Buka **Settings → Pages**.
6. Pada bagian **Build and deployment**, pilih **Deploy from a branch**.
7. Pilih branch `main`, folder `/ (root)`, lalu tekan **Save**.
8. Tunggu proses publikasi. GitHub akan memberikan alamat situs publik, biasanya:
   `https://USERNAME.github.io/data-operasional-catering/`

Siapa pun yang memiliki alamat tersebut dapat membuka halaman data. File `data.json` juga dapat diakses langsung melalui:
`https://USERNAME.github.io/data-operasional-catering/data.json`

## Catatan kualitas data
Rentang durasi di file sumber dinyatakan sebagai estimasi/asumsi awal, bukan pencatatan waktu aktual. Rincian pesanan ditranskripsikan sedekat mungkin dengan sumber. Beberapa hitungan/uraian yang tampak tidak konsisten diberi catatan agar dikonfirmasi, bukan dikoreksi diam-diam.
